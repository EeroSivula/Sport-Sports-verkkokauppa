var removeCartItemButtons = document.getElementsByClassName('removeBtn')
console.log(removeCartItemButtons)
for (var i = 0; i < removeCartItemButtons.length; i ++) {
    var button = removeCartItemButton [i]
    button.addEventListener('click', function(event) {
var buttonClicked = event.target
buttonClicked.parentElement.parentElement.remove()
    })
}

var addToCartButton = document.getElementsByClassName('shop-item-button')
for (var i = 0; i < addToCartButton.length; i ++) {
    var button = addToCartButton[i]
    button.addEventListener('click', addToCartClicked)
}

function addtoCartListener(event) {
    var button = event.target
}